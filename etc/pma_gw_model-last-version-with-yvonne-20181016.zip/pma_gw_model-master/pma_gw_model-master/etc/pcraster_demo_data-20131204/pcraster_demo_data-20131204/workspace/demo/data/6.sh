#!/bin/bash
echo Show the ascii formatted rain.mod model for simulation of rainfall.
echo less rain.mod
less rain.mod