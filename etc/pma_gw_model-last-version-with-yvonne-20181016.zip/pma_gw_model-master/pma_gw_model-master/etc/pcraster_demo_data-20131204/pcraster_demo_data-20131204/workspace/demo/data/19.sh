#!/bin/bash
echo For one timestep, display the actual infiltration map and
echo the input maps used.
echo aguila rainfall.018 infilcap.map infil.map + ldd.map
aguila rainfall.018 infilcap.map infil.map + ldd.map