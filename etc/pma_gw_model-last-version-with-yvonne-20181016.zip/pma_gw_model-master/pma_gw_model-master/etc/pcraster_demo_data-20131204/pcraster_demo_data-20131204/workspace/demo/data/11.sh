#!/bin/bash
echo Show the ascii formatted infilcap.tbl.
echo less infilcap.tbl
less infilcap.tbl