#!/bin/bash
echo List the reported rainfall maps.
echo "ls -l rainfall.*"
ls -l rainfall.*