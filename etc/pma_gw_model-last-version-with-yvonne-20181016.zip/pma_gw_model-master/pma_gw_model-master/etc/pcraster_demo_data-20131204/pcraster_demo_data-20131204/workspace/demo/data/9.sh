#!/bin/bash
echo Animate the reported rainfall maps.
echo aguila --timesteps=[1,28,1] rainfall
aguila --timesteps=[1,28,1] rainfall