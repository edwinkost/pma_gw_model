#!/bin/bash
echo Execute the model
echo pcrcalc -f runoff.mod
pcrcalc -f runoff.mod