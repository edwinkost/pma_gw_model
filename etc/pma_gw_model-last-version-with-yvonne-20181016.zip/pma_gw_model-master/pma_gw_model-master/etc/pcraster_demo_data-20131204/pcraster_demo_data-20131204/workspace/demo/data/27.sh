#!/bin/bash
echo Plot the reported runoff timeseries with the runoff at the two
echo sampling locations.
echo aguila rain.tss runoff.tss
aguila rain.tss runoff.tss