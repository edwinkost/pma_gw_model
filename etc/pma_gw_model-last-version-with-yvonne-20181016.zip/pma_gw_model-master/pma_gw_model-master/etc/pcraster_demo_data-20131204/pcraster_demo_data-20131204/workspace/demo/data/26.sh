#!/bin/bash
echo Show the reported runoff timeseries with the runoff at the two
echo sampling locations on samples.map
echo less runoff.tss
less runoff.tss