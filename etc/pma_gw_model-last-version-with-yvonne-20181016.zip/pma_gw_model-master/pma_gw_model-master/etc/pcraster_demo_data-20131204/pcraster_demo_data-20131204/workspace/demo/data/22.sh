#!/bin/bash
echo Show the results of the model in an animation
echo aguila --timesteps=[1,28,1] runoff
aguila --timesteps=[1,28,1] runoff