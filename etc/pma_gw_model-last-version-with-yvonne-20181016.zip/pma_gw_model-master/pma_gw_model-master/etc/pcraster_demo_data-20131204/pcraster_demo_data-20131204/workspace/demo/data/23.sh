#!/bin/bash
echo Display the sample.map.
echo aguila dem.map + ldd.map samples.map
aguila dem.map + ldd.map samples.map