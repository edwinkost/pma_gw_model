#!/bin/bash
echo Execute the runoff.mod.
echo pcrcalc -f runoff2.mod
pcrcalc -f runoff2.mod