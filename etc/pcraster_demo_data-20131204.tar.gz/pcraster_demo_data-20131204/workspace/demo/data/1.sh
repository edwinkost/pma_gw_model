#!/bin/bash
echo Display the digitial elevation map, the rainstation map and the soil map.
echo aguila dem.map rainstat.map soil.map
aguila dem.map rainstat.map soil.map
