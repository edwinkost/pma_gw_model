#!/bin/bash
echo Display the local drain direction map and the digital elevation model.
echo aguila dem.map + ldd.map
aguila dem.map + ldd.map