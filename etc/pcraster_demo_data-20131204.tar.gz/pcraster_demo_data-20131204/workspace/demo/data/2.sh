#!/bin/bash
echo Show the timeseries with the rainfall at the three rainstations.
echo less rain.tss
less rain.tss