#!/bin/bash
echo Show the runoff2.mod
echo less runoff2.mod
less runoff2.mod