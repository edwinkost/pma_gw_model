#!/bin/bash
echo Display the runoff.map and the ldd.map.
echo aguila infilcap.map runoff.map + ldd.map
aguila infilcap.map runoff.map + ldd.map