#!/bin/bash
echo Display the infiltration capacity map and the soil map.
echo Press any key to execute:
echo aguila infilcap.map soil.map
aguila infilcap.map soil.map