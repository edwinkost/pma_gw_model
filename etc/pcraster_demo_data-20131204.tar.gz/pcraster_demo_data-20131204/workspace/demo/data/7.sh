#!/bin/bash
echo Execute the rainfall simulation model rain.mod.
echo pcrcalc -f rain.mod
pcrcalc -f rain.mod