#!/bin/bash
echo Plot the timeseries with the rainfall at three rainstations.
echo aguila rain.tss
aguila rain.tss