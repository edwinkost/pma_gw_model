#!/bin/bash
echo Display the soil.map
echo aguila soil.map
aguila soil.map